<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

  <title>Dashboard</title>
</head>
<body>

  <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Jumbotron -->
  <div class="jumbotron">

    <div style="border-left: 2px solid white;margin-left: 20%;">
      <h1>Selamat Datang di Maju Jaya Lestari</h1>
      <h2>Salam hangat kami untuk kalian semua</h2>
    </div>

  </div>

</body>
</html>

<?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/resources/views/tampilan/dashboard.blade.php ENDPATH**/ ?>