<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<title>Tambah Sub Menu</title>
</head>
<body>

	<div class="container">
		
		<div class="row">
			
			<div class="offset-lg-4 col-lg-4">

				<form action="/admin/submenu/input" method="post">
					<?php echo e(@csrf_field()); ?>

					<input type="number" name="idMenu" value="<?php echo e($idMenu); ?>" hidden>
					<div class="form-group form-inline">
						<label>Sub Menu : </label>
						<input type="text" name="keterangan" class="form-control">
					</div>

					<button type="submit" class="btn">Simpan</button>
					
				</form>
				
			</div>

		</div>

	</div>

</body>
</html><?php /**PATH D:\xampp\htdocs\majujayalestarirevisi\majujayalestarirevisi\resources\views/admin/submenu/tambahsubmenu.blade.php ENDPATH**/ ?>