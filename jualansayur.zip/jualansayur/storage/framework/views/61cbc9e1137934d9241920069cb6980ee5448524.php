<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="/css/font.css">

	<title>Halaman</title>

	<style type="text/css">
		/* Hide scrollbar for Chrome, Safari and Opera */
		.containerUtama::-webkit-scrollbar {
		  display: none;
		}

		/* Hide scrollbar for IE, Edge and Firefox */
		.containerUtama {
		  -ms-overflow-style: none;  /* IE and Edge */
		  scrollbar-width: none;  /* Firefox */
		}

	</style>
	
</head>
<body>

	<div class="text-center container" style="margin-top: 10vh;margin-bottom: 10vh;">
		<p class="H1">
			Tambah Menu
		</p>
	</div>

	<div class="container containerUtama" style="height: 70vh;background: #FFFFFF;box-shadow: 0px 16px 40px rgba(81, 81, 81, 0.2);border-radius: 20px;padding: 5%;overflow-y: scroll;">
		
		<div class="row">
			
			<div class="col-md-6 text-left">

				<p style="font-weight: bold;font-size: 20px;line-height: 180%;color: #262626;">
					Daftar Menu
				</p>
				
			</div>

			<div class="col-md-6 text-right">

				<form action="/admin/menu/tambah">
					
					<button  style="width: 30%;height: 5vh;background-color: #DB2526;border-radius: 5px;text-decoration: none;color: white;border: none;outline: none;padding-top: 0.5vh;">
						<p>
							+ Tambah Baru
						</p>
					</button>

				</form>
				
			</div>

		</div>

		<table class="container table table-striped ">

		<thead>
			<th>No</th>
			<th>Menu/Submenu</th>
			<th>Aksi</th>
		</thead>

		<tbody>
			<?php $nomor=1;$counter=0; ?>
				
			<?php $__currentLoopData = $Menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Menuu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php $counter=0; ?>

				<?php $__currentLoopData = $SubMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SubMenuu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<?php if($SubMenuu->idSubMenu == $Menuu->idMenu): ?>
						<tr>
							<td><?php echo e($nomor); ?></td>
							<td><?php echo e($Menuu->keterangan); ?> - <?php echo e($SubMenuu->keterangan); ?></td>
							<td>
								<a href="/admin/halaman/edit/<?php echo e($SubMenuu->idMenu); ?>">
									<img src="/FolderGambar/edit.svg">
								</a>
							</td>
						</tr>
						<?php $nomor++;$counter++; ?>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<?php if($counter == 0): ?>
					<tr>
						<td><?php echo e($nomor); ?></td>
						<td><?php echo e($Menuu->keterangan); ?></td>
						<td>
							<a href="/admin/halaman/edit/<?php echo e($Menuu->idMenu); ?>">
								<img src="/FolderGambar/edit.svg">
							</a>
						</td>
					</tr>
					<?php $nomor++; ?>
				<?php endif; ?>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</tbody>
		
	</table>

	</div>

</body>
</html><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/resources/views/admin/halaman.blade.php ENDPATH**/ ?>