<div class="text-light row justify-content-center" style="width: 101%;background-color: #262626;overflow-x: hidden;">

	<div class="col-md-3 text-center">
		
		<img src="Gambar/logo.png" style="width: 20vh;height: 10vh;">
		<h3>PT.Maju Jaya Lestari</h3>

	</div>

	<div class="col-md-2">
		
		<h3>Kunjungi Kami</h3>
		<p>4517 Washington Ave. Manchester, Kentucky 39495</p>

	</div>

	<div class="col-md-2">
		
		<h3>Jam buka</h3>
		<p>Senin-Sabtu <br>
		07.30 AM-08.00 WIB</p>

	</div>

	<div class="col-md-3">
		
		<h3>Kontak</h3>
		<p>Tel:+62819679000</p>
		<p>Fax:+62 21 893 5129, 893 5729</p>
		<p>maju@lestari.com</p>

		<br><br>
		<h3>Search</h3>
		<div class="input-group">
		  <input type="text" class="" style="width: 50%;border: none;height: 5vh;" placeholder="Search...">
		  <div class="input-group-append">
		    <button class="" style="background-color:#ED5148;border: none;" type="button" id="button-addon2"><img src="Homepage/icon search.png" style="width: 3vh;height: 3vh;"></button>
		  </div>
		</div>

	</div>

</div>

<!-- Copyright -->
<div style="margin:0;width: 100%;min-height: 10vh;background-color: #000000;color: white;overflow-x: hidden;padding-top: 20px;">
	
	<div class="row">

		<div class="col-lg-6">
			<h5>Copyright PT.Maju Jaya Lestari</h5>
		</div>
		
		<div class="col-lg-6">
			<ul style="list-style: none;display: inline-block;list-style: none;" class="d-flex justify-content-around">
				<li style="float: left;">Home</li>
				<li style="float: left;">Profil</li>
				<li style="float: left;">Glass Process</li>
				<li style="float: left;">Produk</li>
				<li style="float: left;">Projek</li>
				<li style="float: left;">Kontak</li>
			</ul>
		</div>

	</div>

</div><?php /**PATH /opt/lampp/htdocs/majujayalestari/resources/views/layouts/footer.blade.php ENDPATH**/ ?>