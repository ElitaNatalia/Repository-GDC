<!DOCTYPE html>
<html>
<head>
	<?php echo $__env->make('layouts.source', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<title>Produk</title>
</head>
<body>

	<!-- Hero Section -->
	<div class="sectionn text-center row" style="background-color: #FBF3F2;padding-top: 15vh;margin: 0;">

		<!-- Navbar -->
		<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div class="col-lg-6 " style="margin: 0;padding: 0;">
			
			<p style="font-weight: 600;font-size: 50px;color: #ED5148;">Flower</p>
			<img src="Gambar/background.jpg" style="width: 20vh;height: 20vh;margin-bottom: 5vh;">
			<p style="font-size: 14px;line-height: 150%;color: #999999;width: 40%;margin-left: 30%;">Every sample is hand-made approximately 4″ x 4″ x 1″ thick.</p>
			<div class="row" style="width: 80%;margin-left: 20%;">
				<p style="font-weight: 600;font-size: 30px;line-height: 180%;width: 30%;">Deskripsi</p>
				<hr style="width: 60%;margin-top: 5vh;border: 1px solid #3D3D3D;">
			</div>
			<p style="font-size: 16px;line-height: 150%;color: #999999;width: 80%;margin-left: 20%;text-align: left;">Aliqua id fugiat nostrud irure ex duis ea quis id quis ad et. Sunt qui esse pariatur duis deserunt mollit dolore cillum minim tempor enim. Elit aute irure tempor cupidatat incididunt sint deserunt ut voluptate aute id deserunt nisi.</p>

		</div>

		<div class="col-lg-6" style="margin: 0;padding: 0;">
			
			<div class="row" style="width: 80%;margin-left: 10%;">
				<p style="font-weight: 600;font-size: 30px;line-height: 180%;width: 30%;">Spesifikasi</p>
				<hr style="width: 60%;margin-top: 5vh;border: 1px solid #3D3D3D;">
			</div>

			<!-- Kegunaan -->
			<div class="row " style="width: 85%;margin-left: 10%;">

				<div class="col-lg-3 " style="padding-top: 1vh;">
					
					<p style="font-weight: 500;font-size: 18px;line-height: 180%;">Kegunaan</p>

				</div>
				<div class="offset-lg-1 col-lg-8" style="padding-top: 1vh;">
					
					<p style="font-weight: 500;font-size: 14px;line-height: 150%;color: #999999;text-align: left;">Vanities, table tops, kitchen counters, transaction counters</p>

				</div>

			</div>

			<!-- Berat -->
			<div class="row " style="width: 85%;margin-left: 10%;">

				<div class="col-lg-3 " style="padding-top: 1vh;">
					
					<p style="font-weight: 500;font-size: 18px;line-height: 180%;">Berat</p>

				</div>
				<div class="offset-lg-1 col-lg-8" style="padding-top: 1vh;">
					
					<p style="font-weight: 500;font-size: 14px;line-height: 150%;color: #999999;text-align: left;padding-top: 1vh;">3/4” thick 10lbs./ Sq. ft</p>

				</div>

			</div>

			<!-- Warna -->
			<div class="row " style="width: 85%;margin-left: 10%;">

				<div class="col-lg-3 " style="padding-top: 1vh;">
					
					<p style="font-weight: 500;font-size: 18px;line-height: 180%;">Warna</p>

				</div>
				<div class="offset-lg-1 col-lg-8" style="padding-top: 1vh;">
					
					<p style="font-weight: 500;font-size: 14px;line-height: 150%;color: #999999;text-align: left;padding-top: 1vh;">Low iron, green, crystal clear</p>

				</div>

			</div>

			<!-- Clarity -->
			<div class="row " style="width: 85%;margin-left: 10%;">

				<div class="col-lg-3 " style="padding-top: 1vh;">
					
					<p style="font-weight: 500;font-size: 18px;line-height: 180%;">Clarity</p>

				</div>
				<div class="offset-lg-1 col-lg-8" style="padding-top: 1vh;">
					
					<p style="font-weight: 500;font-size: 14px;line-height: 150%;color: #999999;text-align: left;padding-top: 1vh;">Translucent</p>

				</div>

			</div>

			<!-- Maksimal Dimensi -->
			<div class="row " style="width: 85%;margin-left: 10%;">

				<div class="col-lg-3 " style="padding-top: 1vh;">
					
					<p style="font-weight: 500;font-size: 18px;line-height: 180%;">Maksimal dimensi</p>

				</div>
				<div class="offset-lg-1 col-lg-8" style="padding-top: 1vh;">
					
					<p style="font-weight: 500;font-size: 14px;line-height: 150%;color: #999999;text-align: left;padding-top: 1vh;">12′ x 6′</p>

				</div>

			</div>

			<!-- Safety -->
			<div class="row " style="width: 85%;margin-left: 10%;">

				<div class="col-lg-3 " style="padding-top: 1vh;">
					
					<p style="font-weight: 500;font-size: 18px;line-height: 180%;">Safety</p>

				</div>
				<div class="offset-lg-1 col-lg-8" style="padding-top: 1vh;">
					
					<p style="font-weight: 500;font-size: 14px;line-height: 150%;color: #999999;text-align: left;padding-top: 1vh;">Can be laminated</p>

				</div>

			</div>

		</div>

	</div>

	<!-- Aplikasi -->
	<div style="width: 100%;height: 80vh;background: #FFD2CC;overflow: hidden;">

		<div class="row" style="margin-top: 10vh;margin-left: 10%;">
			<p style="font-weight: 600;font-size: 30px;line-height: 180%;color: #3D3D3D;width: 8%;">Aplikasi</p>
			<hr style="width: 30%;margin-top: 5vh;border: 1px solid #3D3D3D;margin-left: 5%;">
		</div>

		<div class="text-center">
			
			<h1>Ini Carousel Produk</h1>

		</div>
		
	</div>

	<!-- Lihat Sampel Kami -->
	<div style="width: 100%;padding-top: 10vh;padding-bottom: 10vh;overflow: hidden;">
		
		<!-- Menu / SubMenu -->
		<div class="row" style="margin-left: 10%;">
			<p style="font-weight: 600;font-size: 30px;line-height: 180%;color: #3D3D3D;width: 25%;margin-right:0;">Lihat Sampel Kami</p>
			<hr style="width: 60%;margin-top: 5vh;border: 1px solid #3D3D3D;margin-left: 2%;">
		</div>
		<div class="row" style="margin-left: 10%;">
			<a href="#" style="font-size: 14px;line-height: 180%;color: #ED5148;border: none;">Semua</a>/
			<a href="#" style="font-size: 14px;line-height: 180%;color: #616161;border: none;">Cast Glass</a>/
			<a href="#" style="font-size: 14px;line-height: 180%;color: #616161;border: none;">Layered</a>/
			<a href="#" style="font-size: 14px;line-height: 180%;color: #616161;border: none;">Slumped</a>
		</div>

		<!-- Barang -->
		<div class="row justify-content-around " style="margin-left: 15vh;margin-right: 15vh;padding-top: 10vh;">

			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			
		</div>

		<div class="row justify-content-around " style="margin-left: 15vh;margin-right: 15vh;padding-top: 10vh;">

			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			
		</div>

		<div class="row justify-content-around " style="margin-left: 15vh;margin-right: 15vh;padding-top: 10vh;">

			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			
		</div>

		<div class="row justify-content-around " style="margin-left: 15vh;margin-right: 15vh;padding-top: 10vh;">

			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			<div class="col-lg-2 text-center">
				<img src="Gambar/background.jpg" style="width: 100%;height: 25vh;">
				<br><br>
				<p style="font-style: italic;font-weight: normal;font-size: 20px;line-height: 180%;color: #616161;">Tuntrum</p>
			</div>
			
		</div>

	</div>

	<!-- Footer -->
	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>


<?php /**PATH /opt/lampp/htdocs/majujayalestari/resources/views/Produk.blade.php ENDPATH**/ ?>