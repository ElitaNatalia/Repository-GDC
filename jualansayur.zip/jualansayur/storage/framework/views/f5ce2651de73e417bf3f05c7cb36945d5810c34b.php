<!DOCTYPE html>
<html>
<head>

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

  <title>Dashboard</title>

  <style type="text/css">
    body{
      margin: 0;
      padding: 0;
    }
  </style>

</head>
<body>

  <div class="container-fluid justify-content-center" style="max-height: 10vh;background-color: grey;">

    <div class="row">
      
      <div class="col-md-2">
          <img src="/FolderGambar/logo.jpeg" style="height:8vh;width: auto;">
        </div>
        
        <div class="col-md-2">
          <a class="btn" href="/">Beranda</a>
        </div>
        
        <div class="col-md-2">

          <form action="/keranjang">
            <?php echo e(@csrf_field()); ?>


            <?php if(Auth::user()): ?>
              <input type="text" name="username" value="<?php echo e(Auth::user()->username); ?>" hidden>
            <?php endif; ?>

            <button type="submit" class="btn" style="background-color: gray;color: white;">
              Keranjang
            </button>            
          </form>

        </div>
        
        <div class="col-md-2">          
            
        </div>
        
        <div class="col-md-2">
            
        </div>  

        <div class="col-md-2">
          <?php echo $__env->make('layout/check', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
        </div>

    </div>

  </div>

  <br><br>

  <?php $no=1;$harga=0;?>

  <div class="container table-bordered text-center">

    <h1>Nota</h1>
    
  </div>

  <table class="table table-bordered container">

    <thead>
      <th>No</th>
      <th>Nama Barang</th>
      <th>Jumlah Barang</th>
      <th>Harga</th>
    </thead>

    <tbody>
      <?php $__currentLoopData = $notaPenjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penjualan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <?php if($item->idProduk == $penjualan->idProduk): ?>

            <tr>
              <td><?php echo e($no); ?></td>
              <td><?php echo e($item->namaProduk); ?></td>
              <td>1</td>
              <td><?php echo e(number_format($item->harga)); ?></td>
            </tr>

            <?php $harga+= $item->harga; ?>

          <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $no++; ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

    <tfoot>
      <tr>
        <td colspan="3">Total</td>
        <td>Rp. <?php echo e(number_format($harga)); ?></td>
      </tr>
    </tfoot>
    
  </table>

</body>
</html>

<?php /**PATH /opt/lampp/htdocs/jualansayur/resources/views/nota.blade.php ENDPATH**/ ?>