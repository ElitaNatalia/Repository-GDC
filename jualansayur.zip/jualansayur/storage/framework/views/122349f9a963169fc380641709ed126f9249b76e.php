<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="/css/font.css">

	<title>
		<?php echo e($Konten->namaKonten); ?>

	</title>
</head>
<body>

	<div class="row" style="width: 100%;overflow-x: hidden;">

		<div class="col-md-12 text-center" style="padding-top: 10vh;padding-bottom: 10vh;">
			
			<p class="H1">
				Tambah <?php echo e($Konten->namaKonten); ?>

			</p>

		</div>

	</div>

	<div class="container">
		
		<div class="row">

			<div class="col-md-12" style="margin-bottom: 10vh;">

				<form action="/admin/konten/edit/kartu/insert" method="POST" enctype="multipart/form-data">

					<?php echo e(@csrf_field()); ?>


					<input type="number" name="idKonten" value="<?php echo e($Konten->idKonten); ?>" hidden>

					<div class="form-group">
						
						<p class="">
							Judul <?php echo e($Konten->namaKonten); ?> :
						</p>

						<input class="form-control" type="text" name="JudulKartu" value="">
				
					</div>

					<div class="form-group">
						
						<p class="">
							Judul <?php echo e($Konten->namaKonten); ?> :
						</p>

						<input class="form-control" type="text" name="IsiKartu" value="">
				
					</div>


					<div class="form-group">
						
						<p class="">
							Foto <?php echo e($Konten->namaKonten); ?> :
						</p>
						

						<div class="form-inline">

							<input type="file" id="pic" name="FotoKartu" style="display:none" onchange="document.getElementById('filename').value=this.value">
							<input type="text" id="filename" class="form-control" readonly>
							<input type="button" value="Update Foto" class="form-control" onclick="document.getElementById('pic').click()">
				
						</div>

					</div>

					<div class="text-right">						

						<button type="submit" style="background-color: #DB2526;border-radius: 5px;border: none;outline: none;color: white;width: 10%;height: 5vh;">
							Save
						</button>

					</div>

				</form>

			</div>
				

		</div>

	</div>

</body>
</html><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/resources/views/admin/section/kartu/tambahkartu.blade.php ENDPATH**/ ?>