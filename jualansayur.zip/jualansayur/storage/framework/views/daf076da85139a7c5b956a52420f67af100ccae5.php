<div style="width: 100%;overflow-x: hidden;min-height: 100vh;margin: 0;padding: 0;" class="row">

	<?php if($counterKonten == 0): ?>
		<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>


	<div class="col-lg-12" style="margin: 0;padding: 0;">
		
		<img src="<?php echo e(url('/Gambar/Header1/'.$Header11->FotoHeader1)); ?>" style="background-size: cover;background-repeat: no-repeat;background-position: center;width: 100%;height: 100vh;z-index: -2;position: absolute;">

		<div style="margin-top: 20%;margin-left: 10%;width: 40%;z-index: 1;">


			<p style="font-weight: bold;font-size: 30px;line-height: 180%;color: #DB2526;">
				<?php echo e($Header11->JudulHeader1); ?>

			</p>

			<p class="H1" style="color: #EDEDED;">
				<?php echo e($Header11->KeteranganHeader1); ?>

			</p>
			<p class="BodyText" style="color: #EDEDED;">
				<?php echo e($Header11->IsiHeader1); ?>

			</p>
			
		</div>

	</div>
	
</div><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/resources/views/section/Header1.blade.php ENDPATH**/ ?>