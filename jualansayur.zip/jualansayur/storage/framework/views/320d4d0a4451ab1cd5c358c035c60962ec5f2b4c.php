<div style="width: 100%;overflow-x: hidden;min-height: 100vh;padding-top: 10vh;">
	
	<div class="container-fluid">

		<?php if($counterKonten == 0): ?>
			<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php endif; ?>
		
		<div class="row" style="margin-bottom: 10vh;">
			<?php $__currentLoopData = $Berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Beritaa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<div class="col-lg-12 text-center">
					
					<p class="H2" style="color: #6D6D6D;">
						<?php echo e($Beritaa->JudulBerita); ?>

					</p>

					<br>

					<p class="H1" style="color: #000000;">
						<?php echo e($Beritaa->KeteranganBerita); ?>

					</p>

				</div>
				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</div>

		<div class="row d-flex justify-content-center">
			
			<?php $__currentLoopData = $MediaBerita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MediaBeritaa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<div class="col-md-3" style="height: 30vh;overflow: hidden;padding-right: 10px;">

					<img src="<?php echo e(url('/Gambar/Berita/'.$MediaBeritaa->FotoMediaBerita)); ?>" style="background-size: cover;background-repeat: no-repeat;background-position: center;width: 90%;height: 100%;z-index: -2;position: absolute;border-radius: 10px;">

					<div style="position: absolute;bottom: 0;left: 10%;">

						<p class="H3" style="color: #EDEDED;">
							<?php echo e($MediaBeritaa->JudulMediaBerita); ?>

						</p>

						<p class="SmallBodyText" style="color: #EDEDED;">	
							<?php echo e($MediaBeritaa->IsiMediaBerita); ?>

						</p>

					</div>
					
				</div>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</div>

	</div>

</div><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/resources/views/section/Berita.blade.php ENDPATH**/ ?>