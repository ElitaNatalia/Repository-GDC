<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="/css/font.css">
	
	<title>Tambah Menu</title>
</head>
<body>

	<img src="/FolderGambar/Menu.png" style="width: 100%;height: 100vh;background-position: center;background-size: cover;background-repeat: no-repeat;position: absolute;z-index: -5;top: 0;">

	<div class="text-center container" style="margin-top: 10vh;margin-bottom: 10vh;">
		<p class="H1">
			Tambah Sub Menu
		</p>
	</div>

	<div class="container-fluid d-flex justify-content-center">
		
		<div class="text-center" style="border-radius: 20px;width: 25%;height: 60vh;overflow: hidden;padding-top: 15vh;padding-left: 1%;box-shadow: 0px 16px 40px rgba(81, 81, 81, 0.2);">

			<center>
				
				<form action="/admin/menu/input" method="post">			
					
					<?php echo e(@csrf_field()); ?>


							
					<div class="form-group text-left" style="margin-bottom: 5vh;">						
						<label>Menu :</label>
						<input class="form-control" style="width: 80%;" type="text" name="menu">

					</div>

					<div class="container text-right">
						
						<button type="submit" class="btn text-light" style="background-color: #DB2526;border-radius: 5px;">
							Save
						</button>

					</div>

				</form>

			</center>

		</div>

	</div>

</body>
</html><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/resources/views/admin/menu/tambahmenu.blade.php ENDPATH**/ ?>