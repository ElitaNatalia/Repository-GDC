<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="/css/font.css">

	<title>Edit</title>

</head>
<body>

	<img src="/FolderGambar/User Management.png" style="background-repeat: no-repeat;background-position: center;background-size: contain;height: 100vh;width: 100%;position: fixed;z-index: -5;top: 0;">

	<div style="position: relative;z-index: 0;">
		

		<div class="text-center container" style="margin-top: 10vh;">
			<p class="H1">
				Edit User
			</p>
		</div>

        <div class="container">
        
            <a href="/admin/user" class="btn" style="background-color: #A9A9A9;border-radius: 5px;color: white;">
                <img src="/FolderGambar/kiri.svg" style="margin-bottom: 0.5vh;"> Back
            </a>

        </div>

		<div class="container d-flex justify-content-center">

			<div class="col-lg-6" style="position: relative;overflow: hidden;min-height: 60vh;padding-top: 10vh;">

                <form method="POST" action="/admin/user/update">
                        <?php echo e(@csrf_field()); ?>


                    <input type="number" name="id" value="<?php echo e($User->id); ?>" hidden>

                    <div class="form-group">
                        <label for="name" class="col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                        <div class="">
                            <input style="background-color: #EDEDED;" id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e($User->name); ?>" required autocomplete="name" autofocus>

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email" class=" col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                        <div class="">
                            <input style="background-color: #EDEDED;" id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e($User->email); ?>" required autocomplete="email">

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="level" class=" col-form-label text-md-right"><?php echo e(__('Level')); ?></label>

                        <div class="">

                            <div class="form-check">

                                <?php if($User->level == 'Admin'): ?>
                                    <input type="radio" class="form-check-input" name="level" value="Admin" checked>
                                <?php else: ?>
                                    <input type="radio" class="form-check-input" name="level" value="Admin">
                                <?php endif; ?>
                                <label class="form-check-label" for="level">Admin</label>
                                
                            </div>

                            <div class="form-check">

                                <?php if($User->level == 'Operator'): ?>
                                    <input type="radio" class="form-check-input" name="level" value="Operator" checked>
                                <?php else: ?>
                                    <input type="radio" class="form-check-input" name="level" value="Operator">
                                <?php endif; ?>
                                <label class="form-check-label" for="level">Operator</label>
                                
                            </div>

                            <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group mb-0">
                        <div class="">
                            <button type="submit" class="btn" style="background-color: #DB2526;color: white;">
                                Update
                            </button>
                        </div>
                    </div>
                </form>
				
			</div>
			
		</div>

	</div>

</body>
</html><?php /**PATH D:\xampp\htdocs\majujayalestarirevisi\majujayalestarirevisi\resources\views/auth/edituser.blade.php ENDPATH**/ ?>