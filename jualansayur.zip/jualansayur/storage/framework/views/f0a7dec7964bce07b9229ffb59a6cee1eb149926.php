<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="/css/font.css">

	<title>Admin</title>

</head>
<body>

	<img src="/FolderGambar/Admin Dashboard.png" style="background-repeat: no-repeat;background-position: center;background-size: contain;height: 100vh;width: 100%;position: absolute;z-index: -5;">

	<div style="width: 100%;overflow: hidden;height: 100vh;padding: 10%;padding-top: 5vh;">
		

		<div class=" row">

			<?php echo $__env->make('layout.check', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<div class="col-md-12 text-center">
				
				<p class="H1">
					Admin Dashboard
				</p>

			</div>

		</div>

		<br>

		<div class="row justify-content-around">
			
			<div class="col-md-4">
				
				<form action="/admin/menu">

					<button class="container-fluid" style="background-color: #8105D8;min-height: 50vh;border-radius: 10px;padding: 0;">

						<p class="H1" style="color: white;">
							Tambah Menu
						</p>

						<p class="Bodytext" style="color: white;">
							Tempat untuk anda menambah halaman menu dan sub-menu pada website anda
						</p>
						
					</button>
					
				</form>

			</div>

			<div class="col-md-4">				

				<form action="/admin/halaman">

					<button class="container-fluid" style="background-color: #DB2526;min-height: 50vh;border-radius: 10px;padding: 0;">

						<p class="H1" style="color: white;">
							Edit Section
						</p>

						<p class="Bodytext" style="color: white;">
							Tempat untuk anda mengedit section halaman menu dan sub-menu pada website anda
						</p>
						
					</button>
					
				</form>

			</div>

		</div>

		<br><br>

		<?php if(Auth::user()->level == 'Admin'): ?>

			<div class="row justify-content-center">
				
				<div class="col-lg-6">
					
					<form action="/admin/user">

						<button class="container-fluid form-inline" style="background-color: #25DB2C;min-height: 10vh;border-radius: 10px;padding-left: 15%;">

							<i style="color: white;" class="fa fa-user-circle-o fa-2x" aria-hidden="true"></i>

							<p class="H2" style="margin-top: 2vh;margin-left: 10%;color: white;">
								User Management
							</p>
							
						</button>
						
					</form>

				</div>

			</div>

		<?php endif; ?>

	</div>

</body>
</html><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/majujayalestarirevisi/resources/views/admin/admin.blade.php ENDPATH**/ ?>