<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tampilan Email</title>
</head>
<body>
    <h3>Forgot Password Request</h3>

    <h5>
        kami telah menerima "forgot password request" dari akun maju jaya lestari anda.

        Ini adalah password akun anda. mohon simpan kerahasiaan email ini dengan menyimpan
        di tempat yang aman pada email anda.

        Username: <?php echo e($user->name); ?>

        Password: <?php echo e($password); ?>


        Jika anda ingin mengganti password akun anda - silahkan kunjungi halaman
        account management anda.


        admin,
        PT.Maju jaya lestari
    </h5>

</body>
</html><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/majujayalestarirevisi/resources/views/tampilanemail.blade.php ENDPATH**/ ?>