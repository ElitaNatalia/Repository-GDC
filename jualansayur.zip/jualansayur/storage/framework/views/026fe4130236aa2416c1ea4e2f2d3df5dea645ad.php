<div style="width: 100%;overflow-x: hidden;min-height: 100vh;position: relative;margin: 0;" class="row">

	<?php if($counterKonten == 0): ?>
		<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>

	<div class="col-lg-6" style="margin: 0;padding: 0;min-height: 100vh;">

		<div style="width: 80%;z-index: 0;position: absolute;min-height: 100vh;background-color: #292568;">
		</div>

		<img src="<?php echo e(url('Gambar/Profil/'.$Profill->FotoProfil)); ?>" style="background-position: center;background-size: cover;background-repeat: no-repeat;height: 80vh;width: 70%;z-index: 1;position: relative;margin-top: 10vh;margin-left: 30%;">

	</div>

	<div class="col-lg-6" style="margin: 0;padding-left: 5%;padding-top: 10vh;min-height: 100vh;">

		<p class="H2" style="color: #9A9A9A;">
			<?php echo e($Profill->JudulProfil); ?>

		</p>

		<p class="H1">
			<?php echo e($Profill->KeteranganProfil); ?>

		</p>

		<p class="BodyText">
			<?php echo e($Profill->IsiProfil); ?>

		</p>

		
	</div>
	
</div><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/resources/views/section/Profil.blade.php ENDPATH**/ ?>