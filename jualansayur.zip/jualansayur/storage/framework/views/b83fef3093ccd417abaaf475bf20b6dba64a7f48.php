<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">	

	<link rel="stylesheet" type="text/css" href="/css/font.css">

	<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

	<title><?php echo e($IsiMenu->keterangan); ?></title>
</head>
<body>

	<?php $counterKonten =0; ?>

	<?php $__currentLoopData = $Konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Kontenn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<!-- Header1 -->
		<?php $__currentLoopData = $Header1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Header11): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<?php if($Header11->idKonten == $Kontenn->idKonten): ?>
				<?php echo $__env->make('section/Header1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<!-- <h1>Masuk Header1</h1> -->
			<?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<!-- Kolaborasi -->
		<!-- Diberi $no =0 supaya tidak me looping sejumlah data melainkan looping nya berada di dalam view yang saya include -->
		<?php $no=0; ?>
		<?php $__currentLoopData = $Kolaborasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Kolaborasii): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


			<?php if($Kolaborasii->idKonten == $Kontenn->idKonten): ?>
				<?php if($no == 0): ?>
					<?php echo $__env->make('section/Kolaborasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>
				<!-- <h1>Masuk Kolaborasi</h1> -->
				<?php $no++; ?>
			<?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<!-- Profil -->
		<?php $__currentLoopData = $Profil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Profill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<?php if($Profill->idKonten == $Kontenn->idKonten): ?>
			<?php echo $__env->make('section/Profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<!-- <h1>Masuk Profil</h1> -->
			<?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<!-- Kartu -->
		<?php $no=0; ?> 
		<?php $__currentLoopData = $Kartu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Kartuu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<?php if($Kartuu->idKonten == $Kontenn->idKonten): ?>
				<?php if($no == 0): ?>
					<?php echo $__env->make('section/Kartu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>
				<!-- <h1>Masuk Kartuu</h1> -->
				<?php $no++; ?>
			<?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<!-- Media -->
		<?php $__currentLoopData = $Media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Mediaa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


			<?php if($Mediaa->idKonten == $Kontenn->idKonten): ?>

				<?php echo $__env->make('section/Media', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<!-- <h1>Masuk Media</h1> -->

			<?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<?php $__currentLoopData = $Berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Beritaa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<?php if($Beritaa->idKonten == $Kontenn->idKonten): ?>

				<?php echo $__env->make('section/Berita', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<!-- <h1>Masuk Berita</h1> -->

			<?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<?php $__currentLoopData = $Event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Eventt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<?php if($Eventt->idKonten == $Kontenn->idKonten): ?>

				<?php echo $__env->make('section/Event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<!-- <h1>Masuk Event</h1> -->

			<?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<?php $no=0; ?> 
		<?php $__currentLoopData = $Testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Testimoniall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<?php if($no == 0): ?>

				<?php if($Testimoniall->idKonten == $Kontenn->idKonten): ?>

					<?php echo $__env->make('section/Testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<!-- <h1>Masuk Testimonial</h1> -->
					<?php $no++; ?>
					
				<?php endif; ?>

			<?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<?php $counterKonten++; ?>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<?php if($counterKonten == 0): ?>
		<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<script>
  AOS.init();
</script>

</body>
</html><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/majujayalestarirevisi/majujayalestarirevisi/resources/views/tampilan/halaman.blade.php ENDPATH**/ ?>