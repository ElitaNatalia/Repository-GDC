<head>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css"/>
  	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css"/>
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  	<style type="text/css">
  		.slider-for{
  		}
  	</style>

</head>

<div style="width: 100%;overflow-x: hidden;" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1500">

	<?php if($counterKonten == 0): ?>
		<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>
	
	<div class="row">

		<div class="offset-lg-2 col-lg-8 onset-lg-2 text-center" style="position: relative;z-index: 1;min-height: 100vh;padding-top: 20vh;padding-left: 10%;">

			<div class="text-left">

				<div style="height: 1vh;width: 20%;background-color: #DB2526;">					
				</div>
				
				<p class="H1">
					Testimonial
				</p>
				<br>


			</div>

			<!-- Carousel -->
			<div class="slider slider-for justify-content-around" style="margin: 0;min-height: 5vh;">

				<?php $__currentLoopData = $Testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Testimoniall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<div class="text-center">
						
						<p>
							" <?php echo e($Testimoniall->IsiTestimonial); ?> "
						</p>

					</div>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	        </div>

	        <div class="slider slider-foto justify-content-around" style="margin: 0;min-height: 5vh;">

				<?php $__currentLoopData = $Testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Testimoniall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<div class="text-center">
						
						<img style="width: 26%;height: 25vh;border-radius: 100%;margin-left: 37%;margin-right: 37%;" src="<?php echo e(url('/Gambar/Testimonial/'.$Testimoniall->FotoTestimonial)); ?>">
						<br>

					</div>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	        </div>

	        <div class="slider slider-for justify-content-around" style="position: relative;margin: 0;padding: 0;">

				<?php $__currentLoopData = $Testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Testimoniall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<div>
						
						<p>
							<?php echo e($Testimoniall->NamaTestimonial); ?>

						</p>

					</div>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	        </div>

	        <div class="slider slider-for justify-content-around" style="position: relative;margin: 0;padding: 0;">

				<?php $__currentLoopData = $Testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Testimoniall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<div>
						
						<p>
							<?php echo e($Testimoniall->JabatanTestimonial); ?>

						</p>

					</div>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	        </div>


			<!-- Tombol Navigasi -->
	        <div style="margin: 0;">
	          <button class="prev-Profil" style="height: 5vh;outline: none;border: none;border-radius: 50%;background-color: #DB2526;box-shadow: 10px 10px 50px rgba(0, 0, 0, 0.25);"> 
	          	<img src="/FolderGambar/kiri.svg">
	          </button>
	          <button class="next-Profil" style="height: 5vh;outline: none;border: none;border-radius: 50%;background-color: #DB2526;box-shadow: 10px 10px 50px rgba(0, 0, 0, 0.25);">
	          	<img src="/FolderGambar/kanan.svg">
	          </button>
	        </div>

		</div>

	</div>
	
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
  	$('.slider-for').slick({
	  	slidesToShow: 1,
	  	slidesToScroll: 1,
	  	arrows: true,
	  	fade: true,
	  	prevArrow: $('.prev-Profil'),
     	nextArrow: $('.next-Profil'),
	  	asNavFor: '.slider'
	});
	$('.slider-foto').slick({
	  	slidesToShow: 1,
	  	slidesToScroll: 1,
	  	arrows: true,
	  	fade: false,
	  	centerMode: true,
	  	infinite: true,
	  	prevArrow: $('.prev-Profil'),
     	nextArrow: $('.next-Profil'),
	  	asNavFor: '.slider'
	});
	$(".slider").slick({ 
		asNavFor: '.slider'
	 });
});
</script><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/majujayalestarirevisi/resources/views/section/Testimonial.blade.php ENDPATH**/ ?>