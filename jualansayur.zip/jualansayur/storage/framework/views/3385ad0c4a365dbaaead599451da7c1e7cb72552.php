<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="/css/font.css">

	<title>Pilih Section</title>

	<style type="text/css">
		.kartu{
			min-height: 45vh;
			overflow: hidden;
			margin-bottom: 2vh;
			transition: ease-in linear 5s;
		}
		.layer{
			display: none;
			transition: ease-in linear 5s;
		}

		.kartu:hover .layer{
			display: block;
		}
	</style>

</head>
<body>

	<div class="row">
       <div class="col-lg-12 text-center">
          <?php if(session('error')): ?>
           <br>
           <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
          <?php endif; ?>

       </div>
    </div>

    <div class="text-center container" style="margin-top: 10vh;margin-bottom: 10vh;">
		<p class="H1">
			Tambah Section
		</p>
	</div>

	<div class="container">

		<div class="row">
			
			<p class="H2">
				Layout :
			</p>

		</div>

		
		<div class="row" style="min-height: 100vh;">


			<?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectionn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<div class="col-md-4 text-left kartu" style="">					

					<form action="/admin/konten/input" method="post">
						<?php echo e(@csrf_field()); ?>


						<input type="number" name="idMenu" value="<?php echo e($idMenu); ?>" hidden>

						<input type="number" name="idSection" value="<?php echo e($sectionn->idSection); ?>" hidden>

						<div style="position: relative;background: none;outline: none;border: none;">
							
							<img src="/FolderGambar/default.png" style="width: 100%;">


							<p class="text-left SmallBodyText">
								<?php echo e($sectionn->namaSection); ?>

							</p>

							<div class="layer">
								

								<input type="text" name="namaKonten" placeholder="Masukkan nama Konten anda ..." class="form-control">

								<div class="text-right">
									
									<button type="submit" style="background-color: #DB2526;border-radius: 5px;border: none;outline: none;color: white;">
										Save
									</button>

								</div>

							</div>

						</div>

					</form>

				</div>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				

		</div>

	</div>

</body>
</html><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/resources/views/admin/halaman/pilihsection.blade.php ENDPATH**/ ?>