  <style type="text/css">
    .navbar{
      min-height: 10vh;
      width: 100%;
      position: absolute;
      top: 0;
      z-index: 2;
      background-color: grey;
      overflow-x: hidden;
    }
    .tombolLogo{
      max-height: 10vh;
      max-width: 10vh;
    }
    .tombolSearch{
      width: 40px;
      height: 40px;
    }
    .logo{
      width: 5%;
      height: 5%;
    }
    #navbarCollapse{
      margin-top: 1%;
      margin-left: 7%;
    }
    .navbar-brand{
      margin-left: 2%;
      margin-top: 0;
    }
    .inputSearch{
      background: none;
      outline: none;
      border: none;
      border-bottom: 2px solid white;
    }
  </style>

  <nav class="navbar navbar-expand-lg navbar-light ">
    <div class="navbar-header">  
      <img src="Gambar/logo.png" class="tombolSearch" style="width: 40px;height: 40px;">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation" style="position: absolute;right: 2%;">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>

  <div class="collapse navbar-collapse mt-2 offset-lg-2 col-lg-10" id="navbarTogglerDemo02" style="padding-right: 5vh;">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0 ">
      <li class="nav-item">
          <a class="nav-link fontWeight" href="/">HOME</a>
      </li>
      <li class="nav-item">
          <a class="nav-link fontWeight" href="/profil">PROFIL</a>
      </li>
      <li class="nav-item">
          <a class="nav-link fontWeight" href="/glassprocess">GLASS PROCESS</a>
      </li>
      <li class="nav-item">
          <a class="nav-link fontWeight" href="/produk">PRODUK</a>
      </li>
      <li class="nav-item">
          <a class="nav-link fontWeight" href="/projek">PROJEK</a>
      </li>
      <li class="nav-item">
          <a class="nav-link fontWeight" href="/kontak"><p>KONTAK</p></a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <div class="collapse" id="collapseSearch">
        <div class="input-group">
          <input class="inputSearch" type="text" placeholder="Search" aria-label="Search" id="inputSearch">
          <button type="submit" class="input-group-addon" style="background: none;outline: none;border:none;color: red;">Enter</button>
        </div>
      </div>
      <button type="button" id="tombolSearch" class="btn btn-md tombolLogo" data-toggle="collapse" data-target="#collapseSearch" aria-expanded="false" aria-controls="collapseSearch">
        <img src="Gambar/search-white.png" class="tombolSearch">
      </button>
    </form>
  </div>
</nav><?php /**PATH /opt/lampp/htdocs/majujayalestari/resources/views/layouts/navbar.blade.php ENDPATH**/ ?>