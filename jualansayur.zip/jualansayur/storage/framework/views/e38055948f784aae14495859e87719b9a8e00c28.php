<div class="row" style="width: 100%;overflow-x: hidden;height: 100vh;margin: 0;padding: 0;">

	<?php if($counterKonten == 0): ?>
		<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>
	
	<video width="100%" height="100%" controls style="position: relative;z-index: -2;">
		<source src="<?php echo e(url('/Gambar/Media/'.$Mediaa->VideoMedia)); ?>" type="video/mp4">


	</video>

	<div style="position: relative;z-index: 1;">
		
		<p class="H2">
			<?php echo e($Mediaa->JudulMedia); ?>

		</p>

		<p class="BodyText">
			<?php echo e($Mediaa->IsiMedia); ?>

		</p>

	</div>

</div><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/resources/views/section/Media.blade.php ENDPATH**/ ?>