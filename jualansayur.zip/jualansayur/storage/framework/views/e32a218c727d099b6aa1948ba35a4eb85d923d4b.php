<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<title>Edit Urutan</title>
</head>
<body>

	<div class="jumbotron text-center">
		
		<h1><?php echo e($Menu->keterangan); ?></h1>

	</div>	

	<div class="row">
       <div class="col-lg-12 text-center">
          <?php if(session('error')): ?>
           <br>
           <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
          <?php endif; ?>

       </div>
    </div>

	<div class="container text-right">
		<br>
		<form action="/konten/tambah" method="post">
			<?php echo e(@csrf_field()); ?>

			<input type="number" name="idMenu" value="<?php echo e($Menu->idMenu); ?>" hidden>
			<button type="submit" class="btn btn-info">Tambah</button>
		</form>
		<br>
	</div>

	<table class="container table table-striped">
		
		<thead>
			<th>No</th>
			<th>Keterangan</th>
			<th>Aksi</th>
		</thead>

		<tbody>
			
			<?php $__currentLoopData = $Konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Kontenn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<tr>
						
					<td><?php echo e($Kontenn->nomorurut); ?></td>

					<?php if($Kontenn->idSection == 1): ?>
						<td>Carousel</td>
					<?php elseif($Kontenn->idSection == 2): ?>
						<td>Home Biasa</td>
					<?php else: ?>
						<td>Home Dengan Video</td>
					<?php endif; ?>
					<td>
						<a href="/konten/up/<?php echo e($Kontenn->idkonten); ?>" class="btn">^</a>
						<a href="/konten/down/<?php echo e($Kontenn->idkonten); ?>" class="btn">v</a>
						<a href="/konten/hapus/<?php echo e($Kontenn->idkonten); ?>" class="btn btn-warning">Hapus</a>
					</td>

				</tr>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</tbody>

	</table>

</body>
</html><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/resources/views/admin/konten.blade.php ENDPATH**/ ?>