<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="/css/font.css">

	<title>
		<?php echo e($Konten->namaKonten); ?>

	</title>

	<style type="text/css">
		/* Hide scrollbar for Chrome, Safari and Opera */
		.containerUtama::-webkit-scrollbar {
		  display: none;
		}

		/* Hide scrollbar for IE, Edge and Firefox */
		.containerUtama {
		  -ms-overflow-style: none;  /* IE and Edge */
		  scrollbar-width: none;  /* Firefox */
		}

	</style>

</head>
<body>

	<div class="row" style="width: 100%;overflow-x: hidden;">

		<div class="col-md-12 text-center" style="padding-top: 10vh;padding-bottom: 10vh;">
			
			<p class="H1">
				Edit Section
			</p>

		</div>

	</div>

	<div class="container">
		
		<div class="row">

			<div class="col-md-12">
				
			
				<p class="H2">
					Layout :
				</p>

			</div>


			<div class="col-md-12" style="margin-bottom: 10vh;">

				<form action="/admin/konten/edit/event" method="post">

					<?php echo e(@csrf_field()); ?>


					<input type="number" name="idEvent" value="<?php echo e($Section->idEvent); ?>" hidden>

					<input type="number" name="idMenu" value="<?php echo e($Konten->idMenu); ?>" hidden>

					<div class="form-group">
						
						<p class="">
							Judul <?php echo e($Konten->namaKonten); ?> :
						</p>

						<input class="form-control" type="text" name="JudulEvent" value="<?php echo e($Section->JudulEvent); ?>">
				
					</div>

					<div class="form-group">
						
						<p class="">
							Keterangan <?php echo e($Konten->namaKonten); ?> :
						</p>

						<input class="form-control" type="text" name="KeteranganEvent" value="<?php echo e($Section->KeteranganEvent); ?>">
				
					</div>

					<div class="form-group">
						
						<p class="">
							Keterangan <?php echo e($Konten->namaKonten); ?> :
						</p>

						<textarea class="form-control" name="KeteranganEvent">
							<?php echo e($Section->KeteranganEvent); ?>

						</textarea>
				
					</div>

					<div class="text-right">						

						<button type="submit" style="background-color: #DB2526;border-radius: 5px;border: none;outline: none;color: white;width: 10%;height: 5vh;">
							Save
						</button>

					</div>

				</form>

			</div>
				

		</div>

	</div>

	<div class="container containerUtama" style="height: 100vh;background: #FFFFFF;box-shadow: 0px 16px 40px rgba(81, 81, 81, 0.2);border-radius: 20px;padding: 5%;overflow-y: scroll;">
		
		<div class="row">
			
			<div class="col-md-6 text-left">

				<p style="font-weight: bold;font-size: 20px;line-height: 180%;color: #262626;">
					Daftar Event
				</p>
				
			</div>

			<div class="col-md-6 text-right">

				<form action="/admin/konten/edit/mediaevent" method="post">

					<?php echo e(@csrf_field()); ?>


					<input type="number" name="idKonten" value="<?php echo e($Konten->idKonten); ?>" hidden>
					
					<button type="submit" style="width: 30%;height: 5vh;background-color: #DB2526;border-radius: 5px;text-decoration: none;color: white;border: none;outline: none;padding-top: 0.5vh;">
						<p>
							+ Tambah Baru
						</p>
					</button>

				</form>
				
			</div>

			<table class="container table table-striped ">

				<thead>
					<th style="width: 10%;">No</th>
					<th style="width: 20%;">Gambar</th>
					<th style="width: 10%;">Judul</th>
					<th style="width: 10%;">Isi</th>
					<th style="width: 10%;">Aksi</th>
				</thead>

				<tbody>
					<?php $nomor=1; ?>

					<?php $__currentLoopData = $SubSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SubSectionn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<tr>
							<td><?php echo e($nomor); ?></td>
							<td>
								<img src="<?php echo e(url('/Gambar/Event/'.$SubSectionn->FotoMediaEvent)); ?>" style="width: 50%;height: 15vh;">
							</td>
							<td><?php echo e($SubSectionn->NamaMediaEvent); ?></td>
							<td><?php echo e($SubSectionn->TanggalMediaEvent); ?></td>
							<td>
								<a href="/admin/konten/edit/mediaevent/<?php echo e($SubSectionn->idMediaEvent); ?>">
									<img src="/FolderGambar/edit.svg">
								</a>
								<a href="/admin/konten/edit/mediaevent/delete/<?php echo e($SubSectionn->idMediaEvent); ?>">
									<img src="/FolderGambar/delete.svg">
								</a>
							</td>
						</tr>
						<?php $nomor++;?>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</tbody>
				
			</table>

		</div>

	</div>

</body>
</html><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/resources/views/admin/section/event/event.blade.php ENDPATH**/ ?>