<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<title>Edit Sub Menu</title>
</head>
<body>

	<div class="jumbotron text-center">
		<h1>Edit Sub Menu</h1>
	</div>

	<div class="container">
		
		<div class="row">

			<div class="offset-lg-4 col-lg-4 text-center">
				
				<form action="/admin/submenu/update" method="post">

					<?php echo e(@csrf_field()); ?>


					<div class="form-inline">

						<input type="number" name="idMenu" value="<?php echo e($SubMenu->idMenu); ?>" hidden>
						<input type="number" name="idSubMenu" value="<?php echo e($SubMenu->idSubMenu); ?>" hidden>
						<div class="form-group">							
							<label>Sub Menu : </label>
							<input type="text" name="keterangan" class="form-control" value="<?php echo e($SubMenu->keterangan); ?>">
						</div>

						<div class="form-group">
							<label>Status : </label>
							<select name="status" class="form-control">
								<option selected hidden><?php echo e($SubMenu->status); ?></option>
								<option>online</option>
								<option>offline</option>
							</select>
						</div>

					</div>

					<button type="submit" class="btn btn-info">Simpan</button>
					
				</form>

			</div>
			
		</div>

	</div>

</body>
</html><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/resources/views/admin/submenu/editsubmenu.blade.php ENDPATH**/ ?>