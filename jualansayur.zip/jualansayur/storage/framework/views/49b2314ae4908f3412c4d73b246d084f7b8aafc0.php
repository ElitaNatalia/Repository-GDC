<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="/css/font.css">

	<title>
		<?php echo e($Konten->namaKonten); ?>

	</title>

	<style type="text/css">
		/* Hide scrollbar for Chrome, Safari and Opera */
		.containerUtama::-webkit-scrollbar {
		  display: none;
		}

		/* Hide scrollbar for IE, Edge and Firefox */
		.containerUtama {
		  -ms-overflow-style: none;  /* IE and Edge */
		  scrollbar-width: none;  /* Firefox */
		}

	</style>

</head>
<body>

	<div class="text-center container" style="margin-top: 10vh;margin-bottom: 10vh;">
		<p class="H1">
			Edit Section
		</p>
	</div>

	<div class="container">
		<a href="/admin/halaman/edit/<?php echo e($Konten->idMenu); ?>">
			Back
		</a>
	</div>
	<div class="container containerUtama" style="height: 70vh;background: #FFFFFF;box-shadow: 0px 16px 40px rgba(81, 81, 81, 0.2);border-radius: 20px;padding: 5%;overflow-y: scroll;">
		
		<div class="row">
			
			<div class="col-md-6 text-left">

				<p style="font-weight: bold;font-size: 20px;line-height: 180%;color: #262626;">
					List Kartu
				</p>
				
			</div>

			<div class="col-md-6 text-right">

				<form action="/admin/konten/edit/kartu" method="post">

					<?php echo e(@csrf_field()); ?>


					<input type="number" name="idKonten" value="<?php echo e($Konten->idKonten); ?>" hidden>
					
					<button type="submit" style="width: 30%;height: 5vh;background-color: #DB2526;border-radius: 5px;text-decoration: none;color: white;border: none;outline: none;padding-top: 0.5vh;">
						<p>
							+ Tambah Baru
						</p>
					</button>

				</form>
				
			</div>

		</div>

		<table class="container table table-striped ">

		<thead>
			<th style="width: 10%;">No</th>
			<th style="width: 20%;">Gambar</th>
			<th style="width: 10%;">Judul</th>
			<th style="width: 10%;">Isi</th>
			<th style="width: 10%;">Aksi</th>
		</thead>

		<tbody>
			<?php $nomor=1; ?>

			<?php $__currentLoopData = $Section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Sectionn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<tr>
					<td><?php echo e($nomor); ?></td>
					<td>
						<img src="<?php echo e(url('/Gambar/Kartu/'.$Sectionn->FotoKartu)); ?>" style="width: 50%;height: 20vh;">
					</td>
					<td>
						<?php echo e($Sectionn->JudulKartu); ?>

					</td>
					<td>
						<?php echo e($Sectionn->IsiKartu); ?>

					</td>
					<td>
						<a href="/admin/konten/edit/kartu/<?php echo e($Sectionn->idKartu); ?>" style="text-decoration: none;">
							<img src="/FolderGambar/edit.svg">
						</a>
						<a href="/admin/konten/edit/kartu/delete/<?php echo e($Sectionn->idKartu); ?>" style="text-decoration: none;">
							<img src="/FolderGambar/delete.svg">
						</a>
					</td>
				</tr>
				<?php $nomor++; ?>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</tbody>
		
	</table>

	</div>

</body>
</html><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/resources/views/admin/section/kartu/kartu.blade.php ENDPATH**/ ?>