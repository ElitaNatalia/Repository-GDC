<!DOCTYPE html>
<html>
<head>
	<?php echo $__env->make('layouts.source', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<link rel="stylesheet" type="text/css" href="slick/slick.css"/>
  	<link rel="stylesheet" type="text/css" href="slick/slick-theme.css"/>

	<title>Profil</title>
</head>
<body>

	<!-- Hero Section -->
	<div class="sectionn " style="margin: 0;padding: 0;">

		<!-- Navbar -->
		<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		
		<img src="<?php echo e(url('/Profil/'.$Profil->FotoHeroProfil)); ?>" style="width: 100%;height: 100vh;position: absolute;z-index: -1;">

		<div class="VisiMisi" style="width: 30%;min-height: 50vh;margin-top: 25vh;margin-left: 15%;z-index: 2;">
			
			<h1 style="font-style: normal;font-weight: bold;font-size: 50px;color: #ffffff"><?php echo e($Profil->JudulHeroProfil); ?></h1>

		</div>

		<!-- <img src="Gambar/panahturun.png" style="width: 8vh;height: 5%;bottom: 0;position: absolute;margin-left: 45%;">
 		-->
	</div>

	<!-- Intro -->
	<div style="width: 100%;min-height: 30vh;overflow-x: hidden;" class="text-center">
		<div style="margin: 10vh 10%;width: 80%;min-height: 10vh;">
			<p style="font-family: Poppins;font-style: normal;font-weight: normal;font-size: 20px;line-height: 180%;">Hi, Kami adalah Maju Jaya Lestari. Kami dalam misi untuk mempermudah dan menginspirasi belanja produk kaca, jadi anda bisa membuat konstruksi bangunan kesukaan anda.</p>
		</div>
	</div>

	<!-- Visi Misi -->
	<div style="width: 100%;min-height: 240vh;background-color: #FBF3F2;overflow-x: hidden;">

		<?php $Arah=0; ?>

		<?php $__currentLoopData = $TentangSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TentangSectionn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<?php if($Arah%2 == 0): ?>

				<div style="width: 80%;margin: 20vh 10%;min-height: 50vh;background-color: white;margin-bottom: 10vh;overflow-x: hidden;" class="row">
						
					<div class="col-lg-6" style="padding: 0;">
						<img src="Gambar/background.jpg" style="width: 100%;height: 100%;">
					</div>

					<div class="col-lg-6" style="padding-left: 5%;">	

						<br><br>
						<h2>Tentang kami</h2>
						<br>
						<p style="font-style: normal;font-weight: normal;font-size: 14px;line-height: 180%;color: #999999;">Aliqua id fugiat nostrud irure ex duis ea quis id quis ad et. Sunt qui esse pariatur duis deserunt mollit dolore cillum minim tempor enim. Elit aute irure tempor cupidatat incididunt sint deserunt ut voluptate aute id deserunt nisi.</p>

					</div>
						
				</div>
				<?php $Arah++; ?>
			<?php else: ?>

				<div style="width: 80%;margin: 20vh 10%;min-height: 50vh;background-color: white;margin-bottom: 10vh;overflow-x: hidden;" class="row">

					<div class="col-lg-6" style="padding-left: 5%;">	

						<br><br>
						<h2>Visi kami</h2>
						<br>
						<p style="font-style: normal;font-weight: normal;font-size: 14px;line-height: 180%;color: #999999;">Aliqua id fugiat nostrud irure ex duis ea quis id quis ad et. Sunt qui esse pariatur duis deserunt mollit dolore cillum minim tempor enim. Elit aute irure tempor cupidatat incididunt sint deserunt ut voluptate aute id deserunt nisi.</p>

					</div>

					<div class="col-lg-6" style="padding: 0;">
						<img src="Gambar/background.jpg" style="width: 100%;height: 100%;">
					</div>
						
				</div>
				<?php $Arah++; ?>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
	</div>

	<!-- Layanan Kami -->
	<div class="sectionn">
		
		<div class="row ">
			
			<div class="col-lg-12 text-center" style="padding-top: 20vh;">
				<h2 style="font-style: normal;font-weight: 600;font-size: 30px;line-height: 130%;">
					Layanan kami
				</h2>

			</div>

		</div>

		<div class="row justify-content-center" style="margin-top: 5vh;">

			<?php $__currentLoopData = $Layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Layanann): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			
				<div class="col-md-3" style="padding:5%">
					<!-- Logo -->
					<div style="background-color: #FEE2DE;border-radius: 20px;width: 14vh;height: 14vh;">

						<img src="<?php echo e(url('/Layanan/'.$Layanann->FotoLayanan)); ?>" style="width: 8vh;height: 8vh;margin: 3vh;">

					</div>
					<!-- Judul -->
					<br>
					<h4 style="font-style: normal;font-weight: 600;font-size: 18px;line-height: 110%;"><?php echo e($Layanann->JudulLayanan); ?></h4>
					<p style="font-style: normal;font-weight: normal;font-size: 14px;line-height: 180%;">
						<?php echo e($Layanann->IsiLayanan); ?>

					</p>

				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</div>

	</div>

	<!-- Nilai Kami -->
	<div class="sectionn" style="background-color: #FBF3F2;">

		<div class="offset-lg-2 col-lg-8 offset-lg-2 text-center">

			<br>
			<h2 style="font-weight: 600;font-size: 30px;line-height: 180%;">Nilai kami</h2>
			<br>
			<p style="font-size: 18px;line-height: 180%;color: #999999;">Sebuah filosopi atau prinsip yang menjadi panduan perilaku internal organisasi serta hubungannya dengan pelanggan, mitra dan pemegang saham </p>
			
		</div>
		<br>
		<div class="row">
			
			<div class="col-md-6" style="padding-left: 15%;min-height: 60vh;">
				
				<h1 style="color: #ED5148;font-weight: 600;font-size: 50px;line-height: 110%;">Motivasi</h1>
				<h1 class="text-secondary" style="font-weight: 600;font-size: 50px;line-height: 110%;">Bersatu</h1>
				<h1 class="text-secondary" style="font-weight: 600;font-size: 50px;line-height: 110%;">Kepemimpinan</h1>
				<h1 class="text-secondary" style="font-weight: 600;font-size: 50px;line-height: 110%;">Integritas</h1>
				<i class="text-secondary" style="font-weight: 600;font-size: 50px;line-height: 110%;">Accountability</i>

			</div>

			<div class="col-md-6" style="min-height: 60vh;">

				<div style="width: 10%;height: 10vh;background-color: #ED5148;z-index: 0;left: 62%;position: absolute;bottom: 35vh;opacity: 0.7;border-radius: 15px 0px;">
				</div>

				<div style="background-color: #FEE2DE;border-radius: 40px 0px;width: 65%;height: 40vh;position: absolute;bottom: 0;overflow: hidden;padding-left: 8vh;padding-right: 2vh;">
					<br><br>
					<img src="FotoProfil/icon motivasi.png" style="width: 10%;">
					<p style="font-size: 14px;line-height: 180%;">consectetur adipiscing elit duis tristique sollicitudin nibh sit amet commodo nulla facilisi nullam vehicula ipsum a arcu cursus vitae congue</p>

				</div>

			</div>

		</div>
		
	</div>

	<!-- Riwayat Kami -->
	<div class="sectionn">
		
		<p style="font-weight: 600;font-size: 30px;line-height: 180%;margin-top: 15vh;margin-left: 15%;">Riwayat Kami</p>

		<div class="text-center" style="width: 100%;height: 80vh;">
			<br><br><br><br><br><br><br><br>
			<h1>Ini Carousel Riwayat</h1>
		</div>

	</div>

	<!-- Penghargaan -->
	<div class="sectionn text-center">
		<img src="Homepage/Rectangle campur.png" style="z-index: -2;position: absolute;top: 0;left: 0;width: 10%;height: 30vh;">
		<img src="Homepage/Titik awal.png" style="z-index: -2;position: absolute;top: 70%;right: 0;width: 10%;height: 30vh;">
		<br><br><br>
		<p style="font-weight: 600;font-size: 30px;line-height: 180%;">Penghargaan</p>

		<div class="text-center" style="width: 100%;height: 80vh;">
			<br><br><br><br><br><br><br><br>
			<h1>Ini Carousel Penghargaan</h1>
		</div>

	</div>

	<!-- Tertarik bekerja sama dengan kami -->
	<div style="width: 100%;min-height: 50vh;background-image: url('Homepage/Penawaran.png');background-size: cover;background-position: center;overflow-x: hidden;margin-bottom: 20vh;	">
			
		<div class="" style="width: 80%;height: 80%;margin-left: 20%;margin-top:10%;overflow: hidden;">
			
			<p style="font-style: normal;font-weight: bold;font-size: 30px;line-height: 180%;;color: #FFFFFF;">Tertarik bekerja sama dengan kami ?</p>
			<br>
				
			<button style="height: 8vh;width: 25vh;background: white;font-style: normal;font-weight: 600;font-size: 18px;line-height: 180%;color: #ED5148;border: none;">Kontak kami</button>
		</div>

	</div>

	<!-- Footer -->
	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<script type="text/javascript" src="slick/slick.min.js"></script>

	  <script type="text/javascript">
	    $(document).ready(function(){
	      $('.Riwayat-slider').slick({
	         dots: false,
	         arrows : true,
	         slidesToShow: 5,
	         infinite: true
	      	});
	    });
	  </script>
</body>
</html><?php /**PATH /opt/lampp/htdocs/majujayalestari/resources/views/Profil.blade.php ENDPATH**/ ?>