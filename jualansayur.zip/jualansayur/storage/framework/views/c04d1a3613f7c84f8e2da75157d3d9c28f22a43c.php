<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="/css/font.css">

	<title>Halaman</title>

	<style type="text/css">
		/* Hide scrollbar for Chrome, Safari and Opera */
		.containerUtama::-webkit-scrollbar {
		  display: none;
		}

		/* Hide scrollbar for IE, Edge and Firefox */
		.containerUtama {
		  -ms-overflow-style: none;  /* IE and Edge */
		  scrollbar-width: none;  /* Firefox */
		}

	</style>
	
</head>
<body>

	<?php echo $__env->make('layout.check', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<div class="text-center container" >
		<p class="H1">
			User Management
		</p>
	</div>

	<img src="/FolderGambar/User Management.png" style="width: 100%;height: 100vh;background-position: center;background-size: contain;background-repeat: no-repeat;position: absolute;z-index: -5;top: 0;">

	<div class="container">
		
		<a href="/admin" class="btn" style="background-color: #A9A9A9;border-radius: 5px;color: white;">
			<img src="/FolderGambar/kiri.svg" style="margin-bottom: 0.5vh;"> Back
		</a>

	</div>

	<div class="container containerUtama" style="height: 70vh;background: #FFFFFF;box-shadow: 0px 16px 40px rgba(81, 81, 81, 0.2);border-radius: 20px;padding: 5%;overflow-y: scroll;">
		
		<div class="row">
			
			<div class="col-md-6 text-left">

				<p style="font-weight: bold;font-size: 20px;line-height: 180%;color: #262626;">
					Daftar User
				</p>
				
			</div>

			<div class="col-md-6 text-right">

				<form action="/register">
					
					<button  style="width: 30%;height: 5vh;background-color: #DB2526;border-radius: 5px;text-decoration: none;color: white;border: none;outline: none;padding-top: 0.5vh;">
						<p>
							+ Tambah Baru
						</p>
					</button>

				</form>
				
			</div>

		</div>

		<table class="container table table-striped ">

		<thead>
			<th>No</th>
			<th>Nama</th>
			<th>Email</th>
			<th>Level</th>
			<th>Aksi</th>
		</thead>

		<tbody>
			<?php $nomor=1; ?>
				
			<?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Userr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<tr>
					<td><?php echo e($nomor); ?></td>
					<td><?php echo e($Userr->name); ?></td>
					<td><?php echo e($Userr->email); ?></td>
					<td><?php echo e($Userr->level); ?></td>
					<td>
						<a href="/admin/user/edit/<?php echo e($Userr->id); ?>">
							<img src="/FolderGambar/edit.svg">
						</a>
						<a href="/admin/user/delete/<?php echo e($Userr->id); ?>">
							<img src="/FolderGambar/delete.svg">
						</a>
					</td>
				</tr>
				<?php $nomor++; ?>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</tbody>
		
	</table>

	</div>

</body>
</html><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/majujayalestarirevisi/resources/views/auth/user.blade.php ENDPATH**/ ?>