<head>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css"/>
  	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css"/>
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<div style="width: 100%;overflow: hidden;min-height: 100vh;" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1500">

	<?php if($counterKonten == 0): ?>
		<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>
	
	<div class="row">
		
		<div class="col-md-6" style="position: relative;z-index: 0;background-color: #292568;min-height: 100vh;padding-left: 5%;padding-right: 5%;padding-top: 10vh;" data-aos="fade-up">
			
			<p class="H2" style="color: #DB2526;">
				<?php echo e($Eventt->JudulEvent); ?>

			</p>

			<p class="H1" style="color: #FFFFFF;">
				<?php echo e($Eventt->KeteranganEvent); ?>				
			</p>

			<p class="BodyText" style="color: #EDEDED;">
				<?php echo e($Eventt->IsiEvent); ?>				
			</p>

		</div>

		<div class="col-md-6" style="position: relative;z-index: 1;min-height: 100vh;padding-top: 20vh;" data-aos="fade-up">

			<!-- Carousel -->
			<div class="Event-Slider justify-content-around" style="position: relative;left: -10%;">

				<?php $__currentLoopData = $MediaEvent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MediaEventt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<div style="height: 50vh;position: relative;overflow: hidden;padding-right: 10%;padding-bottom: 10%;">
						
						<img src="<?php echo e(url('/Gambar/Event/'.$MediaEventt->FotoMediaEvent)); ?>" style="width: 90%;height: 90%;border-radius: 10px;position: absolute;z-index: -1;">

						<div style="position: absolute;z-index: 1;top: 0;margin: 0;padding: 0;">							

							<p class="H2" style="color: #EDEDED;margin: 0;">
								<?php echo e(date('j F', strtotime($MediaEventt->TanggalMediaEvent))); ?>

							</p>

							<p class="H3" style="color: #EDEDED;margin: 0;">
								<?php echo e($MediaEventt->NamaMediaEvent); ?>

							</p>

						</div>

					</div>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	        </div>

			<!-- Tombol Navigasi -->
	        <div style="position: relative;left: 10%;bottom: 50vh;">
	          <button class="prev-Event" style="height: 5vh;outline: none;border: none;border-radius: 50%;background-color: #DB2526;box-shadow: 10px 10px 50px rgba(0, 0, 0, 0.25);"> 
	          	<img src="/FolderGambar/kiri.svg">
	          </button>
	          <button class="next-Event" style="height: 5vh;outline: none;border: none;border-radius: 50%;background-color: #DB2526;box-shadow: 10px 10px 50px rgba(0, 0, 0, 0.25);">
	          	<img src="/FolderGambar/kanan.svg">
	          </button>
	        </div>

		</div>

	</div>
	
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
  $('.Event-Slider').slick({
     dots: false,
     arrows : true,
     slidesToShow: 2.90,
     infinite: true,
     prevArrow: $('.prev-Event'),
     nextArrow: $('.next-Event')
  });
});
</script><?php /**PATH /opt/lampp/htdocs/majujayalestarirevisi/majujayalestarirevisi/resources/views/section/Event.blade.php ENDPATH**/ ?>