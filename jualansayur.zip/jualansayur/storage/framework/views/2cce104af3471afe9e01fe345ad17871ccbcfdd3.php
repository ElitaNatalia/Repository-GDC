<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- <meta http-equiv="refresh" content="2"> -->

<style>
  body {
    font-family: "Lato", sans-serif;
  }

  .navbar-sticky{
    background-color: black;
  }

  .navbar-samping{
    overflow-x: hidden;
  }

  .nav-container-collapse {
    height: 100%;
    width: 0;
    position: absolute;
    z-index: 4;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
  }

  .nav-container-collapse a, .dropdown-btn {
    padding: 6px 8px 6px 16px;
    text-decoration: none;
    font-size: 20px;
    color: #818181;
    display: block;
    border: none;
    background: none;
    width: 100%;
    text-align: left;
    cursor: pointer;
    outline: none;
  }

  /* On mouse-over */
  .nav-container-collapse a:hover, .dropdown-btn:hover {
    color: #f1f1f1;
  }

  .nav-container-collapse .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
  }
  .dropdown-container {
    display: none;
    background-color: #262626;
    padding-left: 8px;
  }

  /* Optional: Style the caret down icon */
  .fa-caret-down {
    float: right;
    padding-right: 8px;
  }

  @media  screen and (max-height: 450px) {
    .nav-container-collapse {padding-top: 15px;}
    .nav-container-collapse a {font-size: 18px;}
  }
  </style>

<div class="row navbar-sticky" style="width: 100%;overflow-x: hidden;margin: 0;position: absolute;z-index: 2;top: 0;">

  <div class="col-lg-6 text-left " style="padding-left: 5%;">
    
    <h1 style="color: white;">LOGO</h1>

  </div>

  <div class="col-lg-6 text-right " style="padding-right: 5%;">
    
    <button style="background: none;border: none;outline: none;color: white;cursor:pointer;position: absolute;top: 10px;right: 10px;" onclick="openNav()" class="fa fa-times fa-2x"aria-hidden="true"></button>

  </div>

</div>


<div class="nav-container-collapse" id="navbar-samping" style="margin: 0;padding: 0;">

  <div class="row">

    <div class="col-lg-6 text-left " style="padding-left: 5%;">
      
      <h1 style="color: white;">LOGO</h1>

    </div>

    <div class="col-lg-6 text-right " style="padding-right: 5%;">
      
      <button style="background: none;border: none;outline: none;color: white;cursor:pointer;position: absolute;top: 10px;right: 10px;" onclick="closeNav()" class="fa fa-times fa-2x"aria-hidden="true"></button>

    </div>

  </div>

  <div class="row " style="margin-top: 5vh;"> 

    <div class="offset-lg-2 col-lg-8 onset-lg-2">

      <div class="form-group">

        <div class="form-inline row">

          <input class="col-lg-8" placeholder="Search..." type="text" name="search" style="height: 40px;background-color: #EDEDED;border: none;color: black;">

          <select class="col-lg-2" name="menu" style="height: 40px;background-color: #9A9A9A;border: none;color: #EDEDED;">
            <option selected>Home</option>
            <option>Profil</option>
            <option>Program</option>
            <option>Gallery</option>
            <option>Kontak</option>
          </select>

          <button class="col-lg-2" style="background-color: #DB2526;border: none;height: 40px;color: white;padding-top: 1%;">
            <p class="">Gambar Search</p>
          </button>
          
        </div>
        
      </div>        

    </div>
    
  </div>

  <div class="row">
    
    <div class="offset-lg-2 col-lg-8 onset-lg-2">

      <?php $__currentLoopData = $Menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Menuu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $counter=0;$hitungonline=0; ?> <!-- $counter untuk menentukan apakah menu itu dropdown atau tidak -->

        <?php $__currentLoopData = $SubMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SubMenuu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($Menuu->idMenu == $SubMenuu->idSubMenu): ?>
            <?php $counter++; ?>
            <?php if($SubMenuu->status == 'online'): ?>
              <?php $hitungonline++; ?>
            <?php endif; ?>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($Menuu->status == 'online'): ?>

          <?php if($counter > 0 && $hitungonline > 0): ?>

            <button class="dropdown-btn"><?php echo e($Menuu->keterangan); ?> 
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-container">
              <?php $__currentLoopData = $SubMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SubMenuuu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($SubMenuuu->status == 'online'): ?>

                  <?php if($Menuu->idMenu == $SubMenuuu->idSubMenu): ?>

                    <a href="/halaman/<?php echo e($SubMenuuu->idMenu); ?>"><?php echo e($SubMenuuu->keterangan); ?></a>

                  <?php endif; ?>

                <?php endif; ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

          <?php else: ?>

            <a href="/halaman/<?php echo e($Menuu->idMenu); ?>"><?php echo e($Menuu->keterangan); ?></a>

          <?php endif; ?>

        <?php endif; ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </div>

  </div>

</div>

<script type="text/javascript">
  function openNav() {
    document.getElementById("navbar-samping").style.width = "100%";
  }

  function closeNav() {
    document.getElementById("navbar-samping").style.width = "0";
  }
  var dropdown = document.getElementsByClassName("dropdown-btn");
  var i;

  for (i = 0; i < dropdown.length; i++) {
    dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
    dropdownContent.style.display = "none";
    } else {
    dropdownContent.style.display = "block";
    }
    });
  }
</script><?php /**PATH D:\xampp\htdocs\majujayalestarirevisi\majujayalestarirevisi\resources\views/layout/navbar.blade.php ENDPATH**/ ?>