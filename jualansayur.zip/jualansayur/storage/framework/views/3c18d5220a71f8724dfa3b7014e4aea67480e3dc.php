<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
		
<div class="">

    <?php if( !Auth::user() ): ?>
		<div class="dropdown container-fluid">
            <a class="dropdown-item btn" href="/loginuser" style="background-color: #EDEDED;">
                    Login
                </a>
        </div>
		
    <?php else: ?>
        <div class="dropdown container-fluid">
            <a id="navbarDropdown" class="nav-link dropdown-toggle btn" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre style="background-color: #EDEDED;">
                <?php echo e(Auth::user()->username); ?> <span class="caret"></span>
            </a>

            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown" style="background: none;outline: none;border: none;">
                <a class="dropdown-item btn" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();" style="background-color: #EDEDED;">
                    <?php echo e(__('Logout')); ?>

                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
        
    <?php endif; ?>

</div><?php /**PATH /opt/lampp/htdocs/jualansayur/resources/views/layout/check.blade.php ENDPATH**/ ?>