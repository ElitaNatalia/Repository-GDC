<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tampilan Email</title>
</head>
<body>
    <h3>Halo, <?php echo e($nama); ?> !</h3>
    <p><?php echo e($website); ?></p>

    <p>Selamat datang di <a href="https://127.0.0.1:8000">www.majujayalestari.com</a></p>
    <p>Untuk Mengganti Password anda silahkan di bawah ini.</p>
</body>
</html><?php /**PATH D:\xampp\htdocs\majujayalestarirevisi\majujayalestarirevisi\resources\views/tampilanemail.blade.php ENDPATH**/ ?>