<!DOCTYPE html>
<html>
<head>

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

  <title>Dashboard</title>

</head>
<body>

  <div class="container-fluid justify-content-center" style="max-height: 10vh;background-color: grey;">

    <div class="row">
      
      <div class="col-md-2">
          <img src="/FolderGambar/logo.jpeg" style="height:8vh;width: auto;">
        </div>
        
        <div class="col-md-2">
              <a class="btn" href="/">Beranda</a>
        </div>
        
        <div class="col-md-2">
            
        </div>
        
        <div class="col-md-2">          
            
        </div>
        
        <div class="col-md-2">
            
        </div>  

        <div class="col-md-2">
          <?php echo $__env->make('layout/check', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
        </div>

    </div>


  </div>

  <br><br>

  <nav>
    <div class="nav nav-tabs" id="nav-tab" role="tablist">
      <a class="nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Keranjang</a>
      <a class="nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Pesanan</a>
    </div>
  </nav>

  <div class="tab-content" id="nav-tabContent">
    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">

      <div class="container-fluid" style="margin-bottom: 10vh;">

        <div class="row">
          <?php $__currentLoopData = $keranjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <?php if($item->idProduk == $list->idProduk): ?>


                <div class="col-lg-3" style="height: 30vh; margin-bottom: 5vh;">

                  <img src=" <?php echo e(url('/Gambar/produk/'.$item->gambarProduk)); ?> " style="width: 100%; height: 30vh;">

                  <p><?php echo e($item->namaProduk); ?></p>
                  <a href="/keranjang/hapus/<?php echo e($list->idKeranjang); ?>" class="btn btn-danger">
                    Hapus
                  </a>
                  
                </div>           

              <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        
      </div>

      <div class="container">

        <form action="/checkout">

          <?php if(Auth::user()): ?>
            <input type="text" name="username" value="<?php echo e(Auth::user()->username); ?>" hidden>
          <?php endif; ?>

          <button class="btn" style="background-color: grey;color: white;" type="submit">
            Checkout
          </button>

        </form>
        
      </div>

    </div>
    <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">

      <?php $no=1; ?>
      
      <table class="table">

        <thead>
          <th>No</th>
          <th>No.Pemesanan</th>
          <th>Total</th>
          <th>Detail</th>
        </thead>

        <tbody>
          <?php $__currentLoopData = $nota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notaa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $harga=0; ?>
            <tr>
              <td><?php echo e($no); ?></td>
              <td><?php echo e($notaa->idNota); ?></td>

              <?php $__currentLoopData = $notaPenjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penjualan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($notaa->idNota == $penjualan->idNota): ?>

                  <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($item->idProduk == $penjualan->idProduk): ?>
                      <?php $harga+=$item->harga; ?>
                    <?php endif; ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <td>Rp. <?php echo e(number_format($harga)); ?></td>
              <td>
                <a href="/nota/<?php echo e($notaa->idNota); ?>" class="btn btn-info">Detail</a>
              </td>
            </tr>
            <?php $no++; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        
      </table>

    </div>

  </div>

  

</body>
</html>

<?php /**PATH /opt/lampp/htdocs/jualansayur/resources/views/keranjang.blade.php ENDPATH**/ ?>