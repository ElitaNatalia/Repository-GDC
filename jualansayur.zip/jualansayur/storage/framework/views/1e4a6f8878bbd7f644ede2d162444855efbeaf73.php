<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="/css/font.css">

	<title>Buat Menu</title>

	<style type="text/css">
		/* Hide scrollbar for Chrome, Safari and Opera */
		.containerUtama::-webkit-scrollbar {
		  display: none;
		}

		/* Hide scrollbar for IE, Edge and Firefox */
		.containerUtama {
		  -ms-overflow-style: none;  /* IE and Edge */
		  scrollbar-width: none;  /* Firefox */
		}

	</style>
</head>
<body>

	<img src="/FolderGambar/Menu.png" style="width: 100%;height: 100vh;background-position: center;background-size: cover;background-repeat: no-repeat;position: absolute;z-index: -5;top: 0;">

	<div class="text-center container" style="margin-top: 10vh;margin-bottom: 10vh;">
		<p class="H1">
			Tambah Menu
		</p>
	</div>

	<div class="container containerUtama" style="height: 70vh;background: #FFFFFF;box-shadow: 0px 16px 40px rgba(81, 81, 81, 0.2);border-radius: 20px;padding: 5%;overflow-y: scroll;">
		
		<div class="row">
			
			<div class="col-md-6 text-left">

				<p style="font-weight: bold;font-size: 20px;line-height: 180%;color: #262626;">
					Daftar Menu
				</p>
				
			</div>

			<div class="col-md-6 text-right">

				<form action="/admin/menu/tambah">
					
					<button  style="width: 30%;height: 5vh;background-color: #DB2526;border-radius: 5px;text-decoration: none;color: white;border: none;outline: none;">
						<p>
							+ Tambah Baru
						</p>
					</button>

				</form>
				
			</div>

		</div>

		<table class="table table-striped">

			<thead>
				<th style="width: 15%">No.</th>
				<th style="width: 15%">Menu</th>
				<th style="width: 40%">Sub Menu</th>
				<th style="width: 15%">Status</th>
				<th style="width: 15%">Aksi</th>
			</thead>

			<?php $no=1; ?>

			<tbody class="">

				<?php $__currentLoopData = $Menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Menuu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<tr>
						<td><?php echo e($no); ?></td>
						<td><?php echo e($Menuu->keterangan); ?></td>
						<td>

							<?php $__currentLoopData = $SubMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SubMenuu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<?php if($SubMenuu->idSubMenu == $Menuu->idMenu): ?>

									<?php echo e($SubMenuu->keterangan); ?>,

								<?php endif; ?>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</td>

						<?php if($Menuu->status == 'online'): ?>
							<td style="color: green"><?php echo e($Menuu->status); ?></td>
						<?php else: ?>
							<td style="color: red"><?php echo e($Menuu->status); ?></td>
						<?php endif; ?>

						<td>
							<a href="/admin/menu/edit/<?php echo e($Menuu->idMenu); ?>" class="fa fa-pencil" aria-hidden="true"></a>
							<a href="/admin/menu/delete/<?php echo e($Menuu->idMenu); ?>">
								<i class="fa fa-trash"></i>
							</a>
							<a href="/admin/submenu/<?php echo e($Menuu->idMenu); ?>" class="fa fa-eye" aria-hidden="true"></a>
						</td>
					</tr>
					<?php $no++; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</tbody>
			
		</table>

	</div>

</body>
</html><?php /**PATH D:\xampp\htdocs\majujayalestarirevisi\majujayalestarirevisi\resources\views/admin/menu/buatmenu.blade.php ENDPATH**/ ?>