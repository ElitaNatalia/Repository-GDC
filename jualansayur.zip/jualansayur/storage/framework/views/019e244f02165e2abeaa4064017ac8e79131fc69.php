<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

<div class="container-fluid">
	
	<div class="row">
		
		<div class="text-right col-md-12">
				
			<div class="dropdown offset-md-10 col-md-2">
                <a id="navbarDropdown" class="nav-link dropdown-toggle btn" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre style="background-color: #EDEDED;">
                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                </a>

                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown" style="background: none;outline: none;border: none;">
                    <a class="dropdown-item btn" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();" style="background-color: #EDEDED;">
                        <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
			</div>

        </div>
		
	</div>

</div><?php /**PATH D:\xampp\htdocs\majujayalestarirevisi\majujayalestarirevisi\resources\views/layout/check.blade.php ENDPATH**/ ?>