<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// User Login And Registration
Auth::routes();

Route::get('/', 'TampilanController@dashboard');

Route::get('/loginuser', 'TampilanController@login');

Route::post('/tambahitem', 'TampilanController@tambahItem');

Route::get('/keranjang', 'TampilanController@keranjang');

Route::get('/keranjang/hapus/{id}', 'TampilanController@hapuskeranjang');

Route::get('/checkout', 'TampilanController@checkout');

Route::get('/nota/{id}', 'TampilanController@nota');