<!DOCTYPE html>
<html>
<head>

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

  <title>Dashboard</title>

  <style type="text/css">
    body{
      margin: 0;
      padding: 0;
    }
  </style>

</head>
<body>

  <div class="container-fluid justify-content-center" style="max-height: 10vh;background-color: grey;">

    <div class="row">
      
      <div class="col-md-2">
          <img src="/FolderGambar/logo.jpeg" style="height:8vh;width: auto;">
        </div>
        
        <div class="col-md-2">
              <a class="btn" href="#beranda">Beranda</a>
        </div>
        
        <div class="col-md-2">
          
              <a class="btn" href="#produk">Produk</a>
            
        </div>
        
        <div class="col-md-2">
          
              <a class="btn" href="#tentangKami">Tentang Kita</a>
            
        </div>
        
        <div class="col-md-2">
          
              <a class="btn" href="#kontak">Kontak</a>
            
        </div>  

        <div class="col-md-2">
          @include('layout/check')        
        </div>

    </div>


  </div>

  <div class="container-fluid" style="max-height: 90vh;position: relative;padding: 0;margin: 0;">
    
    <img src="/FolderGambar/background.jpeg" style="width: 100%;height: 90vh;z-index: -2;position: relative;">

    <div class="text-light" style="position: absolute;z-index: 1;top: 25vh;margin-left: 20%;">

      <h1>
        FRESH FRUIT & VEGETABLES
      </h1>
      <p>
        Selalu siap melayani anda kapanpun dan dimanapun
      </p>
      <a href="/loginuser" class="btn" style="background-color: red;">Sign Up</a>
      
    </div>

  </div>

  <div class="container-fluid text-right" style="margin-top: 5vh;">
    
    <!-- Keranjang -->
    <div class="container">

      <form action="/keranjang">

        {{ @csrf_field() }}

        @if(Auth::user())
          <input type="text" name="username" value="{{ Auth::user()->username }}" hidden>
        @endif

        <button type="submit" class="btn" style="background-color: gray;color: white;">
          <img src="/FolderGambar/shoppingcart.png">
          Keranjang
        </button>
        
      </form>
      

    </div>

  </div>



  <!-- Produk -->
  <div class="container-fluid" style="min-height: 50vh;position: relative;margin-top: 10vh;">

    <div class="row justify-content-center">

      <div class="col-md-11" style="border-bottom: 2px solid red;height: auto;">

        <h1 id="produk">
          Produk
        </h1>
        
      </div>
      
    </div>

    <br>
    
    <div class="row text-center">
      
      @foreach($produk as $item)

        <div class="col-md-3">

          <div class="container-fluid">

            <img src="{{ url('/Gambar/produk/'.$item->gambarProduk) }}" style="width: 80%;height: 80%;">

            <p>
              {{ $item->namaProduk }}
            </p>

            <p>
              Rp. {{ number_format($item->harga) }}
            </p>

            <form action="/tambahitem" method="POST">

              {{ @csrf_field() }}
              
              <input type="number" name="idProduk" value="{{ $item->idProduk }}" hidden>
              @if(Auth::user())
                <input type="text" name="username" value="{{ Auth::user()->username }}" hidden>
              @endif

              <button type="submit" class="btn form-control" style="background-color: #d0fc72">Beli</button>

            </form>
            
          </div>
          
        </div>

      @endforeach

    </div>

  </div>

  <div class="container justify-content-center" style="padding-top: 30vh;position: relative;height: 100vh;border: 2px solid red;margin-top: 20vh;border-radius: 10%;">

    <img src="/FolderGambar/tentangKami.jpeg" style="position: absolute;top: -10vh;width: 40vh;left: 40%;" id="tentangKami">

    <h3 class="text-center">
      Health Food Co. adalah supermarket <br>
      online, di mana Anda dapat membeli <br>
      sayuran dan buah-buahan segar dan bermutu. <br>

      Kami membuat belanja menjadi lebih mudah dan efisien <br>
       dengan pengiriman 1 hari ke seluruh area Semarang. <br>

       Semua produk yang kami sediakan telah melewati <br>
       proses kontrol mutu internal. <br>
      Kami yakin Health Food Co. dapat mempermudah <br>
      masyarakat memenuhi <br>
      kebutuhan sayur dan buah sehari- hari dengan kualitas tinggi.<br>
    </h3>
    
  </div>

  <div class="container-fluid" style="min-height: 100vh;margin-top: 10vh;background-color: #d0fc72;padding-top: 10vh;">
    
    <div class="container text-center">
      <h1>
        Keuntungan Beli di Toko Kami !
      </h1>
    </div>

    <br>

    <div class="container" style="background-color: white;border-radius: 10px;padding: 5%;">
      
      <div class="row">
          
        <div class="col-md-3 text-center">
          <img src="/FolderGambar/berkualitas.jpeg" style="height: 10vh;">
          <p>
            Kami melakukan
             kontrol mutu agar 
            produk yang
             diterima selalu
             sesuai deskripsi
          </p>
        </div>

        <div class="col-md-3 text-center">
          <img src="/FolderGambar/mudahdancepat.jpeg" style="height: 10vh;">
          <p>
            Tidak perlu repot ke 
            toko. Tidak macet,
             hemat waktu dan 
            tenaga. Pesan lewat 
            hp atau komputer 
            lalu klik produk
             yang  diinginkan
          </p>
        </div>

        <div class="col-md-3 text-center">
          <img src="/FolderGambar/gratisongkir.jpeg" style="height: 10vh;">
          <p>
            gratis ongkir dengan
             minimal pembelian
             Rp 200.000 khusus 
            daerah Semarang
          </p>
        </div>

        <div class="col-md-3 text-center">
          <img src="/FolderGambar/pengiriman.jpeg" style="height: 10vh;">
          <p>
            Bisa mengirim dalam 
            jumlah yang banyak 
            dan cepat sampai
          </p>
        </div>

      </div>        
      
    </div>

  </div>

  <div class="container-fluid text-light" style="background-color: #c46262;">

    <div class="row" id="kontak">
      
      <div class="col-md-6" style="padding-left: 10%;">
        
        <h2>Kontak</h2>
        <p>
          WhatsApp/HP : 08123456789 <br>
          Line : @gtr5fdf
        </p>

      </div>

      <div class="col-md-6" style="padding-left: 10%;">
        <h2>Metode Pembayaran</h2>
        <p>
          Cash/Tunai
        </p>
      </div>

    </div>
    
  </div>

</body>
</html>

