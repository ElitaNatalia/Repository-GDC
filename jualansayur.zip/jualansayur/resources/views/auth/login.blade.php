<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="/css/font.css">

	<title>Login</title>

</head>
<body>

    <div class="container-fluid justify-content-center" style="max-height: 10vh;background-color: grey;">

    <div class="row">
      
      <div class="col-md-2">
          <img src="/FolderGambar/logo.jpeg" style="height:8vh;width: auto;">
        </div>
        
        <div class="col-md-2">
              <a class="btn" href="/">Beranda</a>
        </div>
        
        <div class="col-md-2">


            
        </div>
        
        <div class="col-md-2">
            
        </div>
        
        <div class="col-md-2">
            
        </div>  

        <div class="col-md-2">     
            @include('layout/check') 
        </div>

    </div>


  </div>

    <ul class="nav nav-tabs" id="myTab" role="tablist">
      <li class="nav-item" role="presentation">
        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Login</a>
      </li>
      <li class="nav-item" role="presentation">
        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Sign Up</a>
      </li>
    </ul>

    <div class="tab-content" id="myTabContent">
      <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        <div class="container d-flex justify-content-center">

            <div class="col-lg-6" style="position: relative;overflow: hidden;height: 60vh;padding-top: 10vh;">

                <form method="POST" action="{{ route('login') }}">
                        @csrf

                    <div class="form-group row">

                        <div class="offset-md-3 col-md-6">
                            <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus placeholder="Email" style="background-color: #EDEDED">

                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">

                        <div class="offset-md-3 col-md-6">
                            <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password"placeholder="Password" style="background-color: #EDEDED;">

                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-6 offset-md-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                                <label class="form-check-label SmallBodyText" for="remember">
                                    {{ __('Remember Me') }}
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row mb-0">
                        <div class="offset-md-3 col-md-6">
                            <button type="submit" class="form-control" style="background-color: #DB2526;border-radius: 10px;color: white;">
                                {{ __('Login') }}
                            </button>

                            <hr>

                            @if (Route::has('password.request'))
                                <a class="btn btn-link" href="{{ route('password.request') }}">
                                    {{ __('Forgot Your Password?') }}
                                </a>
                            @endif

                        </div>
                    </div>
                </form>
                
            </div>
            
        </div>

      </div>
      <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">

        <div class="container d-flex justify-content-center">

            <div class="col-lg-6" style="position: relative;overflow: hidden;min-height: 60vh;padding-top: 10vh;">

                <form method="POST" action="{{ route('register') }}">
                        {{ @csrf_field() }}

                    <div class="form-group">
                        <label for="name" class="col-form-label text-md-right">{{ __('Username') }}</label>

                        <div class="">
                            <input style="background-color: #EDEDED;" id="username" type="text" class="form-control @error('username') is-invalid @enderror" name="username" value="{{ old('username') }}" required autocomplete="username" autofocus>

                            @error('username')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email" class=" col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                        <div class="">
                            <input style="background-color: #EDEDED;" id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email" class=" col-form-label text-md-right">{{ __('No Telp') }}</label>

                        <div class="">
                            <input style="background-color: #EDEDED;" id="notelp" type="number" class="form-control @error('notelp') is-invalid @enderror" name="notelp" value="{{ old('notelp') }}" required autocomplete="notelp">

                            @error('notelp')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email" class=" col-form-label text-md-right">{{ __('Alamat') }}</label>

                        <div class="">
                            <input style="background-color: #EDEDED;" id="alamat" type="text" class="form-control @error('alamat') is-invalid @enderror" name="alamat" value="{{ old('alamat') }}" required autocomplete="alamat">

                            @error('alamat')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="password" class=" col-form-label text-md-right">{{ __('Password') }}</label>

                        <div class="">
                            <input style="background-color: #EDEDED;" id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="password-confirm" class=" col-form-label text-md-right">{{ __('Confirm Password') }}</label>

                        <div class="">
                            <input style="background-color: #EDEDED;" id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                        </div>
                    </div>

                    <div class="form-group mb-0">
                        <div class="">
                            <button type="submit" class="btn" style="background-color: #DB2526;color: white;">
                                {{ __('Register') }}
                            </button>
                        </div>
                    </div>
                </form>
                
            </div>
            
        </div>

      </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

</body>
</html>