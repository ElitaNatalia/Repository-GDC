<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="/css/font.css">

	<title>Register</title>

</head>
<body>

	<img src="/FolderGambar/User Management.png" style="background-repeat: no-repeat;background-position: center;background-size: contain;height: 100vh;width: 100%;position: fixed;z-index: -5;top: 0;">

	<div style="position: relative;z-index: 0;">
		

		<div class="text-center container" style="margin-top: 10vh;">
			<p class="H1">
				Register User
			</p>
		</div>

        <div class="container">
        
            <a href="/admin/user" class="btn" style="background-color: #A9A9A9;border-radius: 5px;color: white;">
                <img src="/FolderGambar/kiri.svg" style="margin-bottom: 0.5vh;"> Back
            </a>

        </div>

		<div class="container d-flex justify-content-center">

			<div class="col-lg-6" style="position: relative;overflow: hidden;min-height: 60vh;padding-top: 10vh;">

                <form method="POST" action="/insertuser">
                        {{ @csrf_field() }}

                    <div class="form-group">
                        <label for="name" class="col-form-label text-md-right">{{ __('Name') }}</label>

                        <div class="">
                            <input style="background-color: #EDEDED;" id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                            @error('name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email" class=" col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                        <div class="">
                            <input style="background-color: #EDEDED;" id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="level" class=" col-form-label text-md-right">{{ __('Level') }}</label>

                        <div class="">

                            <div class="form-check">

                                <input type="radio" class="form-check-input" name="level" value="Admin" checked>
                                <label class="form-check-label" for="level">Admin</label>
                                
                            </div>

                            <div class="form-check">

                                <input type="radio" class="form-check-input" name="level" value="Operator" checked>
                                <label class="form-check-label" for="level">Operator</label>
                                
                            </div>

                            @error('level')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="password" class=" col-form-label text-md-right">{{ __('Password') }}</label>

                        <div class="">
                            <input style="background-color: #EDEDED;" id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="password-confirm" class=" col-form-label text-md-right">{{ __('Confirm Password') }}</label>

                        <div class="">
                            <input style="background-color: #EDEDED;" id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                        </div>
                    </div>

                    <div class="form-group mb-0">
                        <div class="">
                            <button type="submit" class="btn" style="background-color: #DB2526;color: white;">
                                {{ __('Register') }}
                            </button>
                        </div>
                    </div>
                </form>
				
			</div>
			
		</div>

	</div>

</body>
</html>