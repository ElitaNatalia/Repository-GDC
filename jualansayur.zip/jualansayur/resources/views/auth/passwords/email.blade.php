<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="/css/font.css">

	<title>Forgot Password</title>

</head>
<body>

	<img src="/FolderGambar/Admin Login.png" style="background-repeat: no-repeat;background-position: center;background-size: contain;height: 100vh;width: 100%;position: absolute;z-index: -5;top: 0;">

	<div style="position: relative;z-index: 0;">
		

		<div class="text-center container" style="margin-top: 10vh;">
			<p class="H1">
				WELCOME TO ADMIN PANEL
			</p>
			<p class="SmallBodyText">
				Access your account to manage all services on your website.
			</p>
		</div>

		<div class="container d-flex justify-content-center">

			<div class="col-lg-6" style="position: relative;overflow: hidden;height: 60vh;padding-top: 10vh;">

				 <form method="POST" action="{{ route('password.email') }}">
                        @csrf

                    <div class="form-group row">
                        <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                        <div class="col-md-6">
                            <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn" style="background-color: #DB2526;color: white;">
                                Submit
                            </button>
                        </div>
                    </div>
                </form>
				
			</div>
			
		</div>

	</div>

</body>
</html>