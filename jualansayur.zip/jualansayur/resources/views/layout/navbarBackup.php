<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  right: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a, .dropdown-btn {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  border: none;
  background: none;
  width: 100%;
  text-align: left;
  cursor: pointer;
  outline: none;
}

/* On mouse-over */
.sidenav a:hover, .dropdown-btn:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}
.dropdown-container {
  display: none;
  background-color: #262626;
  padding-left: 8px;
}

/* Optional: Style the caret down icon */
.fa-caret-down {
  float: right;
  padding-right: 8px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>

<div id="mySidenav" class="sidenav">
  <button style="background: none;border: none;outline: none;color: white;cursor:pointer;position: absolute;top: 10px;right: 10px;" onclick="closeNav()" class="fa fa-times fa-2x"aria-hidden="true"></button>
  
  @foreach($Menu as $Menuu)
  <?php $counter=0;$hitungonline=0; ?> <!-- $counter untuk menentukan apakah menu itu dropdown atau tidak -->

  @foreach($SubMenu as $SubMenuu)
    @if($Menuu->idMenu == $SubMenuu->idSubMenu)
      <?php $counter++; ?>
      @if($SubMenuu->status == 'online')
        <?php $hitungonline++; ?>
      @endif
    @endif
  @endforeach

  @if($Menuu->status == 'online')

    @if($counter > 0 && $hitungonline > 0)

      <button class="dropdown-btn">{{ $Menuu->keterangan }} 
        <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-container">
        @foreach($SubMenu as $SubMenuuu)

          @if($SubMenuuu->status == 'online')

            @if($Menuu->idMenu == $SubMenuuu->idSubMenu)

              <a href="/halaman/{{ $SubMenuuu->idMenu }}">{{ $SubMenuuu->keterangan }}</a>

            @endif

          @endif

        @endforeach
      </div>

    @else

      <a href="/halaman/{{ $Menuu->idMenu }}">{{ $Menuu->keterangan }}</a>

    @endif

  @endif

@endforeach

</div>

<span style="font-size:30px;cursor:pointer;position: absolute;top: 1%;left: 1%;" onclick="openNav()">&#9776;</span>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script>
