<script src="{{ asset('js/app.js') }}" defer></script>
		
<div class="">

    @if( !Auth::user() )
		<div class="dropdown container-fluid">
            <a class="dropdown-item btn" href="/loginuser" style="background-color: #EDEDED;">
                    Login
                </a>
        </div>
		
    @else
        <div class="dropdown container-fluid">
            <a id="navbarDropdown" class="nav-link dropdown-toggle btn" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre style="background-color: #EDEDED;">
                {{ Auth::user()->username }} <span class="caret"></span>
            </a>

            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown" style="background: none;outline: none;border: none;">
                <a class="dropdown-item btn" href="{{ route('logout') }}"
                   onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();" style="background-color: #EDEDED;">
                    {{ __('Logout') }}
                </a>

                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                    @csrf
                </form>
            </div>
        </div>
        
    @endif

</div>