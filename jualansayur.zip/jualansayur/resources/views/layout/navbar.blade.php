<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- <meta http-equiv="refresh" content="2"> -->

<style>
  body {
    font-family: "Lato", sans-serif;
  }

  .navbar-sticky{
    background-color: black;
    position: relative;
    margin-bottom: 10vh;
  }
</style>


<div class="row navbar-sticky justify-content-around" style="width: 100%;overflow-x: hidden;margin: 0;position: absolute;z-index: 2;top: 0;">

  <div class="">
    
    <img src="/FolderGambar/akun.svg" style="width: 20%;height: 10vh;">

  </div>

  <div class="">
    
    <h1 style="color: white;">Beranda</h1>

  </div>

  <div class="">
    
    <h1 style="color: white;">Produk</h1>

  </div>

  <div class="">
    
    <h1 style="color: white;">Tentang Kita</h1>

  </div>

  <div class="">
    
    <h1 style="color: white;">Kontak</h1>

  </div>

</div>